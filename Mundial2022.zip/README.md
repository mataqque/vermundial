# Mira los partidos del Mundial 2022 sin anuncios molestos, (una app creada exclusivamente para vos)

tutorial de como usar la app en mi [tiktok](https://www.tiktok.com/@zalazarc20)